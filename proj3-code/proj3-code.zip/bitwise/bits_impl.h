// DO NOT MODIFY THIS FILE
int bitMatch(int, int);
int evenBits();
int allOddBits();
unsigned floatAbsVal(unsigned);
int implication(int, int);
int isNegative(int);
int sign(int);
int isGreater(int, int);
int logicalShift(int, int);
int rotateRight(int, int);
unsigned floatScale4(unsigned);
int greatestBitPos(int);
// DO NOT MODIFY THIS FILE
